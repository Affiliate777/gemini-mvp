NOTICE — INTERNAL USE ONLY

This folder contains real, runnable examples from the developer's local environment.
DO NOT PUBLISH or share this directory publicly. It contains user-specific paths and example hashes.

If you need a public version, run `tools/generate_public_docs.py` to sanitize the test docs.
