"""
api_gateway.py

Minimal FastAPI gateway for telemetry ingestion (project-local).

Endpoints:
- POST /api/v1/nodes/status
  Body: { "node_id": "name", "payload": { ... } }
  Header (optional): Authorization: Bearer <token>  # enforced only if TELEMETRY_API_TOKEN env is set

Storage:
- SQLite DB at ./runtime/telemetry/remote_ingest.db
- Table: remote_telemetry (id, node_id, timestamp, payload_json)

Run:
  uvicorn api_gateway:app --host 127.0.0.1 --port 8000

Notes:
- The app will accept posts without auth if TELEMETRY_API_TOKEN is not set. To enable auth, set
  export TELEMETRY_API_TOKEN="yourtoken" before running uvicorn.
"""
from __future__ import annotations
import os
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional

from fastapi import FastAPI, Request, HTTPException, Header, status

# App & config
app = FastAPI(title="Gemini Telemetry Gateway", version="0.1")
RUNTIME_DIR = Path("./runtime/telemetry").resolve()
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = RUNTIME_DIR / "remote_ingest.db"

# Optional static token (set TELEMETRY_API_TOKEN env var to enforce)
EXPECTED_TOKEN = os.getenv("TELEMETRY_API_TOKEN")

# DB initialization
def _ensure_db():
    con = sqlite3.connect(str(DB_PATH))
    cur = con.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS remote_telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_id TEXT,
            timestamp TEXT,
            payload TEXT
        )
    """)
    con.commit()
    con.close()

_ensure_db()

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

@app.post("/api/v1/nodes/status")
async def ingest_status(request: Request, authorization: Optional[str] = Header(None)):
    """
    Accepts JSON payload: { "node_id": "<id>", "payload": { ... } }
    If TELEMETRY_API_TOKEN is set, Authorization: Bearer <token> is required.
    """
    # Authorization check (if expected token set)
    if EXPECTED_TOKEN:
        if not authorization:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authorization required")
        # Expect header like: "Bearer <token>"
        parts = authorization.split()
        if len(parts) != 2 or parts[0].lower() != "bearer" or parts[1] != EXPECTED_TOKEN:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    node_id = body.get("node_id")
    payload = body.get("payload")
    if not node_id or payload is None:
        raise HTTPException(status_code=400, detail="Missing 'node_id' or 'payload' in body")

    ts = _now_iso()
    payload_json = json.dumps(payload, default=str)

    # Persist to DB
    con = sqlite3.connect(str(DB_PATH))
    cur = con.cursor()
    cur.execute("INSERT INTO remote_telemetry (node_id, timestamp, payload) VALUES (?, ?, ?)",
                (node_id, ts, payload_json))
    con.commit()
    con.close()

    return {"status": "ok", "node_id": node_id, "timestamp": ts}
