
"""
certify.py - simple Typer-based CLI integrating telemetry into certify commands.

Commands implemented:
- certify telemetry collect [--push]
- certify telemetry show
- certify telemetry scheduler [--interval] [--push]

This is a minimal integration to wire the telemetry module into your existing certify CLI.
"""

from __future__ import annotations
import typer
from pathlib import Path
import telemetry as t

app = typer.Typer(help="Certify CLI - control plane utilities")
telemetry_app = typer.Typer()
app.add_typer(telemetry_app, name="telemetry", help="Telemetry operations")

@telemetry_app.command("collect")
def collect(node_id: str = "local-node", push: bool = False):
    m = t.collect_system_metrics()
    t.push_telemetry(node_id, m, push_remote=push)
    typer.echo(f"[certify] collected telemetry for '{node_id}' at {m['timestamp']}")

@telemetry_app.command("show")
def show(limit: int = 20):
    st = t.get_default_store()
    rows = st.fetch_recent(limit=limit)
    for r in rows:
        typer.echo(r)

@telemetry_app.command("scheduler")
def scheduler(node_id: str = "local-node", interval: int = 30, push: bool = False):
    ic = t.IntervalCollector(node_id=node_id, interval=interval, push_remote=push)
    try:
        ic.start()
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        ic.stop()

if __name__ == "__main__":
    app()
