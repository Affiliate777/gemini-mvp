#!/usr/bin/env bash
cd "$(dirname "$0")"
NODE=${1:-local-node}
INTERVAL=${2:-30}
PUSH=0
for arg in "$@"; do
  if [ "$arg" = "--push" ]; then PUSH=1; fi
done
if [ "$PUSH" -eq 1 ]; then
  exec python3 telemetry.py scheduler "$NODE" "$INTERVAL" --push
else
  exec python3 telemetry.py scheduler "$NODE" "$INTERVAL"
fi
